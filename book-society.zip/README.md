Book Society scaffold. See /server and /client folders.
