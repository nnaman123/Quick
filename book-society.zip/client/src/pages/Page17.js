import React from 'react';
export default function Page17(){return <div style={padding:20}>Placeholder page 17</div>}
