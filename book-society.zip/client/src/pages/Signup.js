import React from 'react';
export default function Signup(){return <div style={{padding:20}}>Signup</div>}
