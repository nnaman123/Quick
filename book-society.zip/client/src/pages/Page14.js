import React from 'react';
export default function Page14(){return <div style={padding:20}>Placeholder page 14</div>}
