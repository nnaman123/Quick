import React from 'react';
export default function Page26(){return <div style={padding:20}>Placeholder page 26</div>}
