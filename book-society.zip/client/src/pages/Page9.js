import React from 'react';
export default function Page9(){return <div style={padding:20}>Placeholder page 9</div>}
