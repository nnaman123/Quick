import React from 'react';
export default function Page13(){return <div style={padding:20}>Placeholder page 13</div>}
