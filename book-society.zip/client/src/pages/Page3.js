import React from 'react';
export default function Page3(){return <div style={padding:20}>Placeholder page 3</div>}
