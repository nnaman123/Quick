import React from 'react';
export default function BookDetails(){return <div style={{padding:20}}>Book Details</div>}
