import React from 'react';
export default function SocietyBooks(){return <div style={{padding:20}}>Society Books</div>}
