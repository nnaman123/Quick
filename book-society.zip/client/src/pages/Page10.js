import React from 'react';
export default function Page10(){return <div style={padding:20}>Placeholder page 10</div>}
