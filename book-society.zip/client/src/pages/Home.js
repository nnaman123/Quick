import React from 'react';
export default function Home(){return <div style={{padding:20}}>Home - Book Society</div>}
