import React from 'react';
export default function Page27(){return <div style={padding:20}>Placeholder page 27</div>}
