import React from 'react';
export default function Page22(){return <div style={padding:20}>Placeholder page 22</div>}
