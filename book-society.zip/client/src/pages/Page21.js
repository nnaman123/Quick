import React from 'react';
export default function Page21(){return <div style={padding:20}>Placeholder page 21</div>}
