import React from 'react';
export default function Page1(){return <div style={padding:20}>Placeholder page 1</div>}
