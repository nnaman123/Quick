import React from 'react';
export default function Page45(){return <div style={padding:20}>Placeholder page 45</div>}
