import React from 'react';
export default function Page2(){return <div style={padding:20}>Placeholder page 2</div>}
