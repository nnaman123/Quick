import React from 'react';
export default function Page44(){return <div style={padding:20}>Placeholder page 44</div>}
