import React from 'react';
export default function Page23(){return <div style={padding:20}>Placeholder page 23</div>}
