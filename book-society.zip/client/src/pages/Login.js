import React from 'react';
export default function Login(){return <div style={{padding:20}}>Login</div>}
