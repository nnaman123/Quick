import React from 'react';
export default function Page18(){return <div style={padding:20}>Placeholder page 18</div>}
