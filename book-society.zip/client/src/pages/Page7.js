import React from 'react';
export default function Page7(){return <div style={padding:20}>Placeholder page 7</div>}
