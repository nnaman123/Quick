import React from 'react';
export default function Page33(){return <div style={padding:20}>Placeholder page 33</div>}
