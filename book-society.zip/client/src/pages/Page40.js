import React from 'react';
export default function Page40(){return <div style={padding:20}>Placeholder page 40</div>}
