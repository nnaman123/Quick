import React from 'react';
export default function Page20(){return <div style={padding:20}>Placeholder page 20</div>}
