import React from 'react';
export default function Page50(){return <div style={padding:20}>Placeholder page 50</div>}
