import React from 'react';
export default function Page6(){return <div style={padding:20}>Placeholder page 6</div>}
