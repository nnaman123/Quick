import React from 'react';
export default function Page15(){return <div style={padding:20}>Placeholder page 15</div>}
