import React from 'react';
export default function Page28(){return <div style={padding:20}>Placeholder page 28</div>}
