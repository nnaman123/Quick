import React from 'react';
export default function Publish(){return <div style={{padding:20}}>Publish</div>}
