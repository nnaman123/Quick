const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET || 'Naman@123';

function sign(payload, opts){
  return jwt.sign(payload, secret, Object.assign({expiresIn:'7d'}, opts));
}

function verify(token){
  try{
    return jwt.verify(token, secret);
  }catch(e){
    return null;
  }
}

module.exports = { sign, verify };
