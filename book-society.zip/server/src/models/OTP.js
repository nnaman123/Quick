const mongoose = require('mongoose');

const OTPSchema = new mongoose.Schema({
  phone: String,
  code: String,
  createdAt: { type: Date, default: Date.now },
  used: { type: Boolean, default: false }
});

OTPSchema.index({ createdAt: 1 }, { expireAfterSeconds: 300 }); // expire 5 minutes
module.exports = mongoose.model('OTP', OTPSchema);
