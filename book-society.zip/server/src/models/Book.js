const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  title: String,
  author: String,
  description: String,
  imageUrl: String,
  publishedAt: { type: Date, default: Date.now },
  isBorrowed: { type: Boolean, default: false },
  borrowedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  dueDate: Date,
  society: String
});

module.exports = mongoose.model('Book', BookSchema);
