const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const User = require('../models/User');
const { verify } = require('../utils/jwt');

function authMiddleware(req,res,next){
  const token = req.headers.authorization?.split(' ')[1];
  const payload = verify(token);
  if(!payload) return res.status(401).json({ error:'unauth' });
  req.userId = payload.id;
  next();
}

// publish book
router.post('/publish', authMiddleware, async (req,res)=>{
  const { title, author, description, imageUrl } = req.body;
  const user = await User.findById(req.userId);
  if(!user) return res.status(400).json({ error:'user not found' });
  const book = new Book({ owner: user._id, title, author, description, imageUrl, society: user.society });
  await book.save();
  res.json({ ok:true, book });
});

// list all books visible to logged-in user (same society)
router.get('/my-society', authMiddleware, async (req,res)=>{
  const user = await User.findById(req.userId);
  const books = await Book.find({ society: user.society }).populate('owner','name flat phone');
  res.json({ books });
});

// list books published by a user
router.get('/by/:userId', authMiddleware, async (req,res)=>{
  const books = await Book.find({ owner: req.params.userId });
  res.json({ books });
});

module.exports = router;
