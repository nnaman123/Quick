const express = require('express');
const router = express.Router();
const User = require('../models/User');
const OTP = require('../models/OTP');
const bcrypt = require('bcryptjs');
const { sign } = require('../utils/jwt');
const { sendMail } = require('../utils/mailer');

// Register (creates user but requires OTP verification)
router.post('/register', async (req,res)=>{
  const { name, email, phone, society, flat, password } = req.body;
  try{
    const existing = await User.findOne({ $or:[{email},{phone}] });
    if(existing) return res.status(400).json({error:'User exists'});
    const passwordHash = password ? await bcrypt.hash(password,10) : undefined;
    const user = new User({ name, email, phone, society, flat, passwordHash });
    await user.save();
    // create an OTP and send email via mailer
    const code = Math.floor(100000 + Math.random()*900000).toString();
    await OTP.create({ phone, code });
    if(email){
      await sendMail(email, 'Your Book Society OTP', `<p>Your OTP: <b>${code}</b></p>`);
    }
    res.json({ ok:true, msg:'Registered. Verify OTP to activate account.', userId: user._id });
  }catch(err){
    console.error(err);
    res.status(500).json({error:'server error'});
  }
});

// Verify OTP
router.post('/verify-otp', async (req,res)=>{
  const { phone, code } = req.body;
  const record = await OTP.findOne({ phone, code, used:false });
  if(!record) return res.status(400).json({ error:'Invalid or expired OTP' });
  record.used = true;
  await record.save();
  const user = await User.findOne({ phone });
  if(!user) return res.status(400).json({ error:'User not found' });
  const token = sign({ id: user._id });
  res.json({ token, user });
});

// Login with email/password or phone/password
router.post('/login', async (req,res)=>{
  const { emailOrPhone, password } = req.body;
  const user = await User.findOne({ $or:[{email:emailOrPhone},{phone:emailOrPhone}] });
  if(!user) return res.status(400).json({ error:'Invalid credentials' });
  if(!user.passwordHash) return res.status(400).json({ error:'No password set — try OTP or OAuth' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if(!ok) return res.status(400).json({ error:'Invalid credentials' });
  const token = sign({ id:user._id });
  res.json({ token, user });
});

// Request OTP code for login
router.post('/request-otp', async (req,res)=>{
  const { phone, email } = req.body;
  const code = Math.floor(100000 + Math.random()*900000).toString();
  if(phone) await OTP.create({ phone, code });
  if(email) await OTP.create({ phone: 'email:'+email, code });
  if(email) await sendMail(email, 'Your Book Society OTP', `<p>Your OTP: <b>${code}</b></p>`);
  res.json({ ok:true, msg:'OTP sent' });
});

module.exports = router;
