const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const User = require('../models/User');
const { verify } = require('../utils/jwt');

// mock payment and borrow
async function auth(req,res,next){
  const token = req.headers.authorization?.split(' ')[1];
  const payload = verify(token);
  if(!payload) return res.status(401).json({ error:'unauth' });
  req.userId = payload.id;
  next();
}

router.post('/rent/:bookId', auth, async (req,res)=>{
  const user = await User.findById(req.userId);
  const book = await Book.findById(req.params.bookId);
  if(!book) return res.status(404).json({ error:'book not found' });
  if(book.society !== user.society) return res.status(403).json({ error:'Book not in your society' });
  if(book.isBorrowed) return res.status(400).json({ error:'Already borrowed' });
  // check if user already has an active borrow
  const hasActive = await Book.findOne({ borrowedBy: user._id, isBorrowed: true });
  if(hasActive) return res.status(400).json({ error:'Return previous book first' });
  book.isBorrowed = true;
  book.borrowedBy = user._id;
  book.dueDate = new Date(Date.now() + 7*24*3600*1000);
  await book.save();
  const owner = await User.findById(book.owner);
  const fee = 10; // rupees service fee
  owner.balance = (owner.balance || 0) + (10 - fee*0.1);
  await owner.save();
  res.json({ ok:true, book });
});

router.post('/return/:bookId', auth, async (req,res)=>{
  const user = await User.findById(req.userId);
  const book = await Book.findById(req.params.bookId);
  if(!book) return res.status(404).json({ error:'book not found' });
  if(String(book.borrowedBy) !== String(user._id) && String(book.owner) !== String(user._id)) return res.status(403).json({ error:'Not allowed' });
  book.isBorrowed = false;
  book.borrowedBy = null;
  book.dueDate = null;
  await book.save();
  res.json({ ok:true, book });
});

module.exports = router;
