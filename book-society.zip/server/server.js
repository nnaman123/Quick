require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const authRoutes = require('./src/routes/auth');
const bookRoutes = require('./src/routes/books');
const borrowRoutes = require('./src/routes/borrow');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 5000;

// connect mongo
mongoose.connect(process.env.MONGO_URI, { })
  .then(()=> console.log('Mongo connected'))
  .catch(err => console.error('Mongo connect err', err));

app.use('/api/auth', authRoutes);
app.use('/api/books', bookRoutes);
app.use('/api/borrow', borrowRoutes);

app.get('/', (req,res)=> res.send({status:'ok', msg:'Book Society API'}));

app.listen(PORT, ()=> console.log('Server running on', PORT));
